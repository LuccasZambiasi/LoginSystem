<?php
require_once "config.php";
?>

<!DOCTYPE html>
<html>
    <head>
        <title>LaSalle - Bem-vindo</title>
        <meta charset="utf-8"/>
        <link href="https://fonts.googleapis.com/css?family=Ubuntu&display=swap" rel="stylesheet">
         <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/css/mdb.min.css" rel="stylesheet">
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.11/js/mdb.min.js"></script>

    </head>
    <style>
    body {
        margin: 0;
        width: 100%;
        height: 100vh;
        font-family: "Exo", sans-serif;
        color: #fff;
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradientBG 15s ease infinite;
    }
    @keyframes gradientBG {
        0% {
            background-position: 0% 50%;
        }
        50% {
            background-position: 100% 50%;
        }
        100% {
            background-position: 0% 50%;
        }
    }
    .container {
        width: 100%;
        position: absolute;
        top: 35%;
        text-align: center;
    }
    h1 {
      font-weight: 300;
    }
    h3 {
        color: #eee;
        font-weight: 100;
    }
    h5 {
        color:#eee;
        font-weight:300;
    }
    a,a:hover {
        text-decoration: none;
        color: #ddd;
    }
    div.polaroid {
        width: 280px;
        background-color: white;
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        margin-bottom: 20px;
        top: -120px;
        left: 45%;
        position: absolute;
    }
    div.box {
        text-align: center;
        padding: 1px 2px;
    }
    </style>
    <body>
        <div class="container">
            <center>
            <div class="polaroid">
                <img src="http://novamarca.lasalle.edu.br/wp-content/uploads/2018/05/social-media-lasalle.png" alt="Norther Lights" style="width:100%">
                <div class="box">
                   <p style="font-family: 'Ubuntu', sans-serif; margin-top: 0px;"><a href="/login.php" style="text-decoration: none; color: black;"><b>Login</b></a> <br> <a href="/register.php" style="text-decoration: none; color: black;"><b>Registrar</b></a></p>                    
                    <button style="font-family: 'Ubuntu'" type="button"  data-toggle="modal" data-target="#observacao" class="btn btn-outline-primary waves-effect"><b>Observações</b></button>

                </div>
            </div>
            </center>
        </div>
    </body>
<!-- Full Height Modal Right -->
<div class="modal fade right" id="observacao" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-full-height modal-right" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title w-100" id="myModalLabel" style="color: black; font-family: 'Ubuntu'">INFORMAÇÕES LEGAIS</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="color: black; font-family: 'Ubuntu'; text-align: justify">
        Desde já agradeço por ter feito o download da 2a versão do projeto SimpleLogin. Esse site consiste em um simples sistema de 
        registro e login com PHP e MYSQL.
        <br><br>
        - Observações:
        <br><br>
        Para a construção do projeto, foi utilizado recursos de GETBOOSTRAP.COM, W3SCHOOLS.COM, CODEPEN.IO, NOVAMARCA.LASALLE.EDU.BR.
        <br><br>
        Esse projeto <b>NÃO</b> possúi nenhum vínculo com a Rede La Salle. Utilizei a logo da Rede pois sou um estudante da unidade LaSalle Esteio. Caso for necessário a retirada das imagens, favor entrar em contato que será feito assim de imediato.
        <br><br>
        v2.0 do projeto concluída em 08.dez.2019.
      </div>
      <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">Ok.</button>
      </div>
    </div>
  </div>
</div>
<!-- Full Height Modal Right -->

</html>