<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Controle do Aluno - LaSalle</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/painel.css">
    <link href="https://fonts.googleapis.com/css?family=Nunito&display=swap" rel="stylesheet">

    <style type="text/css">
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div class="header">
        <img src="images/logo.png" style="width: 240px; height: 100px; margin-top: 5px; float: left; margin-left: 10px;">
        <h1 style="padding-left: 10px; margin-top: 40px; text-align: left; left: 250px; position: absolute;">≫ <b>PORTAL DO ALUNO</b></h1>
    </div>
    <div class="content">
    <h3 style="text-align: left; margin-right: 5px; font-family: 'Nunito', sans-serif; top: -10px; position: relative;">
        Usuário: <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>
        | Matrícula: <b><?php echo htmlspecialchars($_SESSION["id"]); ?></b>
        <a href="reset.php" class="btn btn-warning">Alterar Senha</a>
        <a href="logout.php" class="btn btn-danger">Deslogar</a>
        <hr>
    </h3>
        <h2>Menu do Aluno</h2>
    </div>    
</body>
    <footer>
     <h4><em>developed by <a href="https://twitter.com/zaaptbr" style="text-decoration: none; color: #006eff;">@zaaptbr</a></em>.</h4>
    </footer>
</html>